.. my_package.refael_kohen documentation master file, created by
   sphinx-quickstart on Tue Jun  9 01:25:03 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to my_package.refael_kohen's documentation!
===================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
